﻿using System.Collections.Generic;

namespace ConsoleApp1
{
    class DAL
    {
        public static List<Employee> Employees = new List<Employee>();
        public static List<Department> Departments = new List<Department>();
    }
}
