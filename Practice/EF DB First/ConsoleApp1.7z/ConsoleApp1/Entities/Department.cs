﻿
namespace ConsoleApp1
{
    class Department
    {
        public byte DID { get; set; }
        public string DName { get; set; }
    }
}
